fetch("http://localhost:3000/api/foods")
  .then((res) => res.json())
  .then((foods) => {
    const foodList = document.getElementById("food-list");
    const searchInput = document.getElementById("searchInput");

    function render(foodsToShow) {
      foodList.innerHTML = "";
      foodsToShow.forEach((food) => {
        const card = document.createElement("div");
        card.className = "col-md-4";
        card.innerHTML = `
          <div class="card">
            <img src="${food.image}" class="card-img-top" alt="${food.name}" />
            <div class="card-body">
              <h5 class="card-title">${food.name}</h5>
              <p class="card-text">${food.description}</p>
              <p class="card-text"><strong>$${food.price}</strong></p>
              <p class="card-text text-muted">Category: ${food.category}</p>
              <button class="btn btn-primary">Order</button>
            </div>
          </div>`;
        foodList.appendChild(card);
      });
    }

    render(foods);
    searchInput.addEventListener("input", () => {
      const term = searchInput.value.toLowerCase();
      const filtered = foods.filter(f => f.name.toLowerCase().includes(term));
      render(filtered);
    });
  });
