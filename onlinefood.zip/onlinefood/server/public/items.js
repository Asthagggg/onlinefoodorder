function addToCart(foodItemId, name, price) {
  const quantity = parseInt(document.getElementById(`quantity-${foodItemId}`).value);
  const numericPrice = parseFloat(price); // Convert price to number
  let cart = JSON.parse(localStorage.getItem('cart')) || [];

  // Check if item already exists in cart
  const existingItem = cart.find(item => item.id === foodItemId);
  if (existingItem) {
    existingItem.quantity += quantity;
  } else {
    cart.push({ id: foodItemId, name, price: numericPrice, quantity });
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  alert(`${name} added to cart!`);
}