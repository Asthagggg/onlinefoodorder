const stripe = Stripe('your-publishable-key'); // Your Stripe publishable key

// Dummy cart data - you should fetch it dynamically
const cartItems = [
  { name: 'Chicken Momo', price: 6, quantity: 2 },
  { name: 'Paneer Butter Masala', price: 10, quantity: 1 }
];

// Display cart summary
const cartTotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
document.getElementById('cartTotal').textContent = cartTotal.toFixed(2);

const cartItemsList = document.getElementById('cartItemsList');
cartItems.forEach(item => {
  const li = document.createElement('li');
  li.textContent = `${item.name} - $${item.price} x ${item.quantity}`;
  cartItemsList.appendChild(li);
});

// Handle Checkout Button click
document.getElementById('checkoutButton').addEventListener('click', async function () {
  const userId = localStorage.getItem('userId'); // Assuming userId is stored in localStorage

  try {
    // Step 1: Create payment intent on the server
    const response = await fetch('/api/payment/create-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ cartItems: cartItems, userId: userId }),
    });
    const data = await response.json();

    if (data.clientSecret) {
      // Step 2: Confirm the payment with Stripe
      const { clientSecret } = data;

      const { error } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: cardElement, // cardElement is the Stripe element (refer to Stripe docs)
          billing_details: {
            name: 'John Doe', // Replace with actual user data
            email: 'john@example.com', // Replace with actual user email
          },
        },
      });

      if (error) {
        alert('Payment failed: ' + error.message);
      } else {
        // Step 3: Handle successful payment
        if (data.paymentIntent.status === 'succeeded') {
          alert('Payment Successful!');
          // Optionally, store the order in your database
          // You can redirect the user to an order confirmation page or update their dashboard
        }
      }
    }
  } catch (err) {
    console.error('Error during checkout process', err);
    alert('An error occurred during checkout. Please try again.');
  }
});

// Set up Stripe Elements for the card input field
const elements = stripe.elements();
const cardElement = elements.create('card');
cardElement.mount('#card-element');
