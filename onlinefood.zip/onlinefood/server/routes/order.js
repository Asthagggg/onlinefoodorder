const express = require('express');
const pool = require('../db');
const { verifyToken, ensureAdmin } = require('../middleware/authMiddleware');

const router = express.Router();

// Place a new order
router.post('/', verifyToken, async (req, res) => {
  const { items, totalPrice, paymentStatus } = req.body;
  const userId = req.userId;
  let totalOrderPrice = 0;

  try {
    // Validate food items and calculate total price
    for (const item of items) {
      const foodItem = await pool.query('SELECT id, name, price, image_url FROM food_items WHERE id = $1', [item.food_item_id]);
      if (foodItem.rows.length === 0) {
        return res.status(400).json({ message: `Food item with ID ${item.food_item_id} not found` });
      }
      totalOrderPrice += foodItem.rows[0].price * item.quantity;
    }

    // Ensure the provided totalPrice matches the calculated totalOrderPrice
    if (Math.abs(totalPrice - totalOrderPrice) > 0.01) {
      return res.status(400).json({ message: 'Total price mismatch' });
    }

    // Create the order in the orders table
    const newOrder = await pool.query(
      'INSERT INTO orders (user_id, total_price, status, order_date, created_at) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [userId, totalOrderPrice, paymentStatus, new Date(), new Date()]
    );
    console.log('neworder', newOrder);
    const orderId = newOrder.rows[0].id;

    // Add the items to the order_items table
    for (const item of items) {
      await pool.query(
        'INSERT INTO order_items (order_id, food_item_id, quantity, price) VALUES ($1, $2, $3, $4)',
        [orderId, item.food_item_id, item.quantity, item.price]
      );
    }

    res.status(201).json({ message: 'Order placed successfully', orderId });
  } catch (error) {
    console.error('Error placing order:', error);
    res.status(500).json({ message: 'Error placing order', error: error.message });
  }
});

// View user's orders (Order history)
router.get('/', verifyToken, async (req, res) => {
  try {
    const orders = await pool.query(
      `SELECT o.id, o.created_at, o.total_price, o.status, oi.food_item_id, oi.quantity, fi.name AS food_name, fi.image_url AS food_image
       FROM orders o
       JOIN order_items oi ON o.id = oi.order_id
       JOIN food_items fi ON oi.food_item_id = fi.id
       WHERE o.user_id = $1
       ORDER BY o.created_at DESC`,
      [req.userId]
    );
    res.json(orders.rows);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ message: 'Error fetching orders', error: error.message });
  }
});

// Admin: Get all orders
router.get('/admin', verifyToken, ensureAdmin, async (req, res) => {
  try {
    const orders = await pool.query(
      `SELECT o.id, o.created_at, o.total_price, o.status, u.name AS customer_name,
              json_agg(
                json_build_object(
                  'food_item_id', oi.food_item_id,
                  'name', fi.name,
                  'quantity', oi.quantity,
                  'price', oi.price
                )
              ) AS items
       FROM orders o
       LEFT JOIN users u ON o.user_id = u.id
       JOIN order_items oi ON o.id = oi.order_id
       JOIN food_items fi ON oi.food_item_id = fi.id
       GROUP BY o.id, u.name
       ORDER BY o.created_at DESC`
    );
    res.json(orders.rows);
  } catch (error) {
    console.error('Error fetching orders for admin:', error);
    res.status(500).json({ message: 'Error fetching orders for admin', error: error.message });
  }
});

// Admin: Sales report with date range filter
router.get('/sales-report', verifyToken, ensureAdmin, async (req, res) => {
  const { start_date, end_date } = req.query;
  try {
    let query = `
      SELECT o.id, o.created_at, o.total_price, o.status, 
             COALESCE(u.name, 'Guest') AS customer_name,
             json_agg(
               json_build_object(
                 'food_item_id', oi.food_item_id,
                 'name', fi.name,
                 'quantity', oi.quantity,
                 'price', oi.price
               )
             ) AS items
      FROM orders o
      LEFT JOIN users u ON o.user_id = u.id
      JOIN order_items oi ON o.id = oi.order_id
      JOIN food_items fi ON oi.food_item_id = fi.id
    `;
    const params = [];
    
    if (start_date && end_date) {
      query += ` WHERE o.created_at BETWEEN $1 AND $2`;
      params.push(start_date, end_date);
    }
    
    query += ` GROUP BY o.id, u.name ORDER BY o.created_at DESC`;

    const orders = await pool.query(query, params);
    
    // Calculate totals
    const totalSales = orders.rows.reduce((sum, order) => sum + parseFloat(order.total_price), 0);
    const itemSummary = {};
    orders.rows.forEach(order => {
      order.items.forEach(item => {
        if (!itemSummary[item.food_item_id]) {
          itemSummary[item.food_item_id] = { name: item.name, quantity: 0, revenue: 0 };
        }
        itemSummary[item.food_item_id].quantity += item.quantity;
        itemSummary[item.food_item_id].revenue += item.quantity * parseFloat(item.price);
      });
    });

    res.json({
      orders: orders.rows,
      totalSales: totalSales.toFixed(2),
      itemSummary: Object.values(itemSummary)
    });
  } catch (error) {
    console.error('Error generating sales report:', error);
    res.status(500).json({ message: 'Error generating sales report', error: error.message });
  }
});

// Update order status
router.put('/update/:orderId', verifyToken, async (req, res) => {
  const { orderId } = req.params;
  const { status } = req.body;

  try {
    const order = await pool.query('SELECT * FROM orders WHERE id = $1', [orderId]);
    if (order.rows.length === 0) {
      return res.status(404).json({ message: 'Order not found' });
    }

    if (order.rows[0].user_id !== req.userId && req.role !== 'admin') {
      return res.status(403).json({ message: 'You are not authorized to update this order' });
    }

    await pool.query('UPDATE orders SET status = $1 WHERE id = $2', [status, orderId]);
    res.json({ message: 'Order status updated successfully' });
  } catch (error) {
    console.error('Error updating order status:', error);
    res.status(500).json({ message: 'Error updating order status', error: error.message });
  }
});

module.exports = router;