const express = require('express');
const pool = require('../db');
const { verifyToken, ensureAdmin } = require('../middleware/authMiddleware');

const router = express.Router();

// Fetch all food items
router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT id, name, description, price::float AS price, image_url FROM food_items');
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching food items:', error);
    res.status(500).json({ message: 'Error fetching food items', error: error.message });
  }
});

// Add a new food item (Admin only)
router.post('/', verifyToken, ensureAdmin, async (req, res) => {
  const { name, description, price, image_url } = req.body;

  if (!name || !price) {
    return res.status(400).json({ message: 'Food name and price are required' });
  }

  try {
    const newFoodItem = await pool.query(
      'INSERT INTO food_items (name, description, price, image_url) VALUES ($1, $2, $3, $4) RETURNING *',
      [name, description, price, image_url]
    );
    res.status(201).json(newFoodItem.rows[0]);
  } catch (error) {
    console.error('Error adding food item:', error);
    res.status(500).json({ message: 'Error adding food item', error: error.message });
  }
});

// Update a food item (Admin only)
router.put('/:id', verifyToken, ensureAdmin, async (req, res) => {
  const { id } = req.params;
  const { name, description, price, image_url } = req.body;

  try {
    const updatedFoodItem = await pool.query(
      'UPDATE food_items SET name = $1, description = $2, price = $3, image_url = $4 WHERE id = $5 RETURNING *',
      [name, description, price, image_url, id]
    );
    if (updatedFoodItem.rows.length === 0) {
      return res.status(404).json({ message: 'Food item not found' });
    }
    res.json(updatedFoodItem.rows[0]);
  } catch (error) {
    console.error('Error updating food item:', error);
    res.status(500).json({ message: 'Error updating food item', error: error.message });
  }
});

// Delete a food item (Admin only)
router.delete('/:id', verifyToken, ensureAdmin, async (req, res) => {
  const { id } = req.params;

  try {
    const deletedFoodItem = await pool.query(
      'DELETE FROM food_items WHERE id = $1 RETURNING *',
      [id]
    );
    if (deletedFoodItem.rows.length === 0) {
      return res.status(404).json({ message: 'Food item not found' });
    }
    res.json({ message: 'Food item deleted successfully' });
  } catch (error) {
    console.error('Error deleting food item:', error);
    res.status(500).json({ message: 'Error deleting food item', error: error.message });
  }
});

module.exports = router;