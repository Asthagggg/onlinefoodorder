const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('../db');
require('dotenv').config();

const router = express.Router();

// Utility function to limit admin users
const canCreateAdmin = async () => {
  const result = await pool.query(`SELECT COUNT(*) FROM users WHERE role = 'admin'`);
  return parseInt(result.rows[0].count) < 2;
};

// SIGNUP
router.post('/signup', async (req, res) => {
  const { name, email, password, role } = req.body;
  try {
    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Name, email, and password are required' });
    }

    const existingUser = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    // If trying to create an admin, check the limit
    if (role === 'admin') {
      const allowed = await canCreateAdmin();
      if (!allowed) {
        return res.status(403).json({ message: 'Maximum of 2 admins allowed' });
      }
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = await pool.query(
      'INSERT INTO users (name, email, password, role) VALUES ($1, $2, $3, $4) RETURNING id, name, email, role',
      [name, email, hashedPassword, role || 'user']
    );

    const token = jwt.sign(
      { userId: newUser.rows[0].id, email: newUser.rows[0].email, role: newUser.rows[0].role },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.status(201).json({
      message: 'User registered successfully',
      token,
      name: newUser.rows[0].name,
      role: newUser.rows[0].role,
      userId: newUser.rows[0].id
    });
  } catch (err) {
    console.error('Signup Error:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// LOGIN
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }

    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    const user = result.rows[0];

    if (!user) return res.status(400).json({ message: 'Invalid email or password' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: 'Invalid email or password' });

    const token = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.status(200).json({
      message: 'Login successful',
      token,
      role: user.role,
      userId: user.id,
      name: user.name
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(400).json({ message: 'Login error: ' + err.message });
  }
});

// LOGOUT
router.get('/logout', (req, res) => {
  // Since using localStorage, inform client to clear it
  res.status(200).json({ message: 'Logged out successfully. Please clear localStorage.' });
});

module.exports = router;