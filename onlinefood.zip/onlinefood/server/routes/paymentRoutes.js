const express = require('express');
const Stripe = require('stripe');
const pool = require('../db');
require('dotenv').config();

const router = express.Router();
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

// Create Payment Intent
router.post('/create-payment-intent', async (req, res) => {
  const { cartItems, userId } = req.body;
  console.log('Creating payment intent:', { cartItems, userId });

  if (!cartItems || !Array.isArray(cartItems) || cartItems.length === 0) {
    return res.status(400).json({ message: 'Cart items are required' });
  }

  try {
    const amount = cartItems.reduce((total, item) => {
      return total + parseFloat(item.price) * item.quantity * 100; // Convert to cents
    }, 0);

    if (amount <= 0) {
      return res.status(400).json({ message: 'Invalid payment amount' });
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount),
      currency: 'usd',
      payment_method_types: ['card'],
      metadata: {
        userId: userId || 'guest',
        cartItems: JSON.stringify(cartItems)
      }
    });

    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (err) {
    console.error('Error creating payment intent:', err.stack);
    res.status(500).json({ message: 'Error creating payment intent', error: err.message });
  }
});

// Webhook to handle payment events
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    console.log('Webhook event received:', event.type);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.stack);
    return res.status(400).json({ message: 'Webhook Error: ' + err.message });
  }

  if (event.type === 'payment_intent.succeeded') {
    const paymentIntent = event.data.object;
    const { userId, cartItems } = paymentIntent.metadata;
    console.log('Payment succeeded, metadata:', { userId, cartItems });

    try {
      const parsedCartItems = JSON.parse(cartItems);
      console.log('Parsed cart items:', parsedCartItems);

      // Validate food items and adjust prices
      for (const item of parsedCartItems) {
        const foodItem = await pool.query('SELECT id, price FROM food_items WHERE id = $1', [item.food_item_id]);
        if (foodItem.rows.length === 0) {
          throw new Error(`Food item with ID ${item.food_item_id} not found`);
        }
        // Use database price to ensure consistency
        item.price = parseFloat(foodItem.rows[0].price);
        console.log(`Adjusted price for food_item_id ${item.food_item_id}: ${item.price}`);
      }

      const totalPrice = parsedCartItems.reduce((total, item) => {
        return total + parseFloat(item.price) * item.quantity;
      }, 0);
      console.log('Calculated total price:', totalPrice);

      // Validate user_id
      let dbUserId = userId === 'guest' ? null : parseInt(userId);
      if (dbUserId) {
        const user = await pool.query('SELECT id FROM users WHERE id = $1', [dbUserId]);
        if (user.rows.length === 0) {
          throw new Error(`User with ID ${dbUserId} not found`);
        }
      }

      // Insert into orders table
      const orderResult = await pool.query(
        'INSERT INTO orders (user_id, total_price, status, order_date, created_at) VALUES ($1, $2, $3, $4, $5) RETURNING id',
        [dbUserId, totalPrice, 'completed', new Date(), new Date()]
      );
      console.log('Order inserted:', orderResult.rows[0]);

      const orderId = orderResult.rows[0].id;

      // Insert into order_items table
      for (const item of parsedCartItems) {
        await pool.query(
          'INSERT INTO order_items (order_id, food_item_id, quantity, price) VALUES ($1, $2, $3, $4)',
          [orderId, parseInt(item.food_item_id), parseInt(item.quantity), parseFloat(item.price)]
        );
        console.log('Inserted order item:', { orderId, food_item_id: item.food_item_id });
      }

      console.log(`Order ${orderId} created for user ${userId}`);
      
    } catch (err) {
      console.error('Error saving order:', err.stack);
      return res.status(500).json({ message: 'Error saving order: ' + err.message });
    }
  }

  res.json({ received: true });
});

module.exports = router;