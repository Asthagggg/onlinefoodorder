const express = require('express');
const router = express.Router();
const pool = require('../db'); // PostgreSQL pool
const { verifyAdmin } = require('../middleware/auth'); // Admin check middleware

// Get all food items
router.get('/foods', verifyAdmin, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM food');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ message: 'Failed to get food items' });
  }
});

// Add a new food item
router.post('/foods', verifyAdmin, async (req, res) => {
  const { name, description, price, image } = req.body;
  try {
    await pool.query(
      'INSERT INTO food (name, description, price, image) VALUES ($1, $2, $3, $4)',
      [name, description, price, image]
    );
    res.status(201).json({ message: 'Food item added' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to add food item' });
  }
});

// Update a food item
router.put('/foods/:id', verifyAdmin, async (req, res) => {
  const { id } = req.params;
  const { name, description, price, image } = req.body;
  try {
    await pool.query(
      'UPDATE food SET name = $1, description = $2, price = $3, image = $4 WHERE id = $5',
      [name, description, price, image, id]
    );
    res.json({ message: 'Food item updated' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to update food item' });
  }
});

// Delete a food item
router.delete('/foods/:id', verifyAdmin, async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM food WHERE id = $1', [id]);
    res.json({ message: 'Food item deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete food item' });
  }
});

// Sales report
router.get('/sales', verifyAdmin, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT food.name, SUM(order_items.quantity) AS total_sold, SUM(order_items.quantity * order_items.price) AS revenue
      FROM order_items
      JOIN food ON food.id = order_items.food_id
      GROUP BY food.name
    `);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ message: 'Failed to generate report' });
  }
});

module.exports = router;
