// routes/dashboard.js
const express = require('express');
const router = express.Router();
const {
  ensureAuthenticated,
  ensureAdmin,
  ensureUser
} = require('../middleware/authMiddleware');

// USER dashboard
router.get('/user-profile', ensureAuthenticated, ensureUser, (req, res) => {
  res.send(`Welcome to your profile, ${req.session.user.name}`);
});

// ADMIN dashboard
router.get('/admin-dashboard', ensureAuthenticated, ensureAdmin, (req, res) => {
  res.send(`Welcome Admin ${req.session.user.name}`);
});

module.exports = router;
